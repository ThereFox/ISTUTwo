﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace lab3
{
    public partial class Form1 : Form
    {
        public string FileName;
        public int FlagFile;
        public Form1()
        {
            InitializeComponent();

            In();
        }

        public void In()
        {
            FileName = "";
            FlagFile = 0;
            Title();
        }

        public void NewDocument(object sender, EventArgs e)
        {
            textBox1.Text = "";
            FileName = "";
            Title();
           
        }

        public void OpenDocument(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader a = new StreamReader(openFileDialog1.FileName);
                textBox1.Text = a.ReadToEnd();
                a.Close();
                FileName = openFileDialog1.FileName;
            }
            Title();
        }

        public void SaveDocument(string _filename)
        {
           
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    _filename = saveFileDialog1.FileName;
                }
            
            try
            {
                StreamWriter b = new StreamWriter(saveFileDialog1.FileName);
                b.Write(textBox1.Text);
                b.Close();
                FileName = _filename;
                FlagFile = 0;
            }
            catch
            {
                MessageBox.Show("Error");
            }
        }
        public void Save(object sender, EventArgs e)
        {
            SaveDocument(FileName);
        }

        public void Title()
        {
            if (FileName != "")
            {
                this.Text = FileName + " - Блокнот";
            }
            else
            {
                this.Text = "NoName" + " - Блокнот";
            }
        }

        public void Exit(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Вы точно хотите выйти? Все несохранённые файлы будут утеряны.", "Подтверждение", MessageBoxButtons.OK);
            if (r == DialogResult.OK) {
                this.Close();
            }
            
        }
         public void Time(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(DateTime.Now) + " " + textBox1.Text;
        }

        public void Info(object sender, EventArgs e)
        {
            Form2 info = new Form2();
            info.Show();
        }
        public void Dark(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.FromArgb(4, 3, 4);
            textBox1.ForeColor = System.Drawing.Color.White; 
            menuStrip1.BackColor = Color.FromArgb(18, 6, 18);
            menuStrip1.ForeColor = System.Drawing.Color.White;
        }
        public void Light(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.FromArgb(255, 255, 255);
            textBox1.ForeColor = System.Drawing.Color.Black;
            menuStrip1.BackColor = Color.FromArgb(255, 255, 255);
            menuStrip1.ForeColor = System.Drawing.Color.Black;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
